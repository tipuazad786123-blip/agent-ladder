import unittest

from level4_multi_agent import Orchestrator


class MultiAgentTests(unittest.TestCase):
    def test_full_pipeline(self):
        result = Orchestrator().run("Explain machine learning and compute 12*8+4")
        self.assertTrue(result.completed)
        self.assertIn("# Report: machine learning", result.report)
        self.assertIn("12*8+4 = 100", result.report)
        self.assertIn("learn patterns", result.report)

    def test_research_only_goal(self):
        result = Orchestrator().run("Explain python")
        self.assertTrue(result.completed)
        self.assertNotIn("Calculation", result.report)

    def test_agents_talk_through_messages(self):
        result = Orchestrator().run("Explain git and compute 2+2")
        senders = {m.sender for m in result.transcript}
        self.assertEqual(senders, {"user", "planner", "researcher", "analyst", "writer"})

    def test_message_limit_guardrail(self):
        result = Orchestrator(max_messages=2).run("Explain git and compute 2+2")
        self.assertFalse(result.completed)


if __name__ == "__main__":
    unittest.main()
