"""Level 4 - Multi-agent team: specialists coordinated by an orchestrator over a message bus."""

from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field

from tools import calculator, format_number, lookup


@dataclass
class Message:
    sender: str
    recipient: str
    kind: str
    content: str = ""
    data: dict = field(default_factory=dict)


class Specialist:
    name = "specialist"

    def handle(self, msg: Message) -> list[Message]:
        raise NotImplementedError


class Planner(Specialist):
    """Splits a goal like 'Explain python and compute 12*8+4' into tasks."""

    name = "planner"

    def handle(self, msg: Message) -> list[Message]:
        parts = re.split(r"\s*\band\s+compute\s+|\s*\bcompute\s+", msg.content.strip(), maxsplit=1, flags=re.I)
        topic = re.sub(r"^(explain|research|report on|write about)\s+", "", parts[0].strip(), flags=re.I).strip(" .,")
        expression = parts[1].strip(" .?") if len(parts) == 2 else None

        tasks = [Message(self.name, "researcher", "task", topic)]
        if expression:
            tasks.append(Message(self.name, "analyst", "task", expression))
        plan = Message(self.name, "writer", "plan", data={"expected": len(tasks), "topic": topic})
        return [plan, *tasks]


class Researcher(Specialist):
    name = "researcher"

    def handle(self, msg: Message) -> list[Message]:
        text = lookup(msg.content) or f"No notes found for '{msg.content}'."
        return [Message(self.name, "writer", "result", text, {"section": "Research"})]


class Analyst(Specialist):
    name = "analyst"

    def handle(self, msg: Message) -> list[Message]:
        try:
            text = f"{msg.content} = {format_number(calculator(msg.content))}"
        except ValueError as error:
            text = f"Could not compute '{msg.content}': {error}"
        return [Message(self.name, "writer", "result", text, {"section": "Calculation"})]


class Writer(Specialist):
    name = "writer"
    ORDER = ("Research", "Calculation")

    def __init__(self):
        self.expected = 0
        self.topic = ""
        self.sections: dict[str, str] = {}

    def handle(self, msg: Message) -> list[Message]:
        if msg.kind == "plan":
            self.expected = msg.data["expected"]
            self.topic = msg.data["topic"]
            self.sections = {}
            return []
        self.sections[msg.data["section"]] = msg.content
        if self.expected and len(self.sections) >= self.expected:
            body = "\n\n".join(f"## {name}\n{self.sections[name]}" for name in self.ORDER if name in self.sections)
            return [Message(self.name, "user", "report", f"# Report: {self.topic}\n\n{body}\n")]
        return []


@dataclass
class RunResult:
    report: str
    transcript: list[Message]
    completed: bool


class Orchestrator:
    """Routes messages between specialists. max_messages is a guardrail against loops."""

    level = 4
    name = "Multi-Agent Team"

    def __init__(self, max_messages: int = 50):
        self.max_messages = max_messages
        self.agents = {agent.name: agent for agent in (Planner(), Researcher(), Analyst(), Writer())}

    def run(self, goal: str) -> RunResult:
        bus = deque([Message("user", "planner", "goal", goal)])
        transcript: list[Message] = []
        report, completed = "", False
        while bus and len(transcript) < self.max_messages:
            msg = bus.popleft()
            transcript.append(msg)
            if msg.recipient == "user":
                report, completed = msg.content, True
                continue
            agent = self.agents.get(msg.recipient)
            if agent:
                bus.extend(agent.handle(msg))
        return RunResult(report, transcript, completed)
