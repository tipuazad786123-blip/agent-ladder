"""Level 3 - Memory and planning agent: remembers facts and runs multi-step plans."""

from __future__ import annotations

import json
import re
from pathlib import Path

from level2_tools import ToolAgent
from tools import format_number


class MemoryAgent:
    level = 3
    name = "Memory & Planning Agent"

    def __init__(self, path: str | Path | None = None):
        self.tools = ToolAgent()
        self.path = Path(path) if path else None
        self.facts: dict[str, str] = {}
        self.notes: list[str] = []
        self.history: list[tuple[str, str]] = []
        self._load()

    # ---- persistence -------------------------------------------------
    def _load(self) -> None:
        if self.path and self.path.exists():
            data = json.loads(self.path.read_text())
            self.facts = data.get("facts", {})
            self.notes = data.get("notes", [])

    def _save(self) -> None:
        if self.path:
            self.path.write_text(json.dumps({"facts": self.facts, "notes": self.notes}, indent=2))

    # ---- planning ----------------------------------------------------
    @staticmethod
    def plan(goal: str) -> list[str]:
        """Split a goal into ordered steps on 'then', 'and then' or ';'."""
        parts = re.split(r"\s*(?:\band then\b|\bthen\b|;)\s*", goal.strip(), flags=re.I)
        return [part for part in parts if part]

    def run_plan(self, goal: str) -> str:
        """Run each step with the tool agent. The word 'ans' means the previous numeric result."""
        lines, last = [], None
        for number, step in enumerate(self.plan(goal), start=1):
            if last is not None:
                step = re.sub(r"\bans\b", format_number(last), step, flags=re.I)
            result = self.tools.act(step)
            if result.value is not None:
                last = result.value
            lines.append(f"Step {number}: {step} -> {result.output}")
        return "\n".join(lines)

    # ---- conversation ------------------------------------------------
    def respond(self, text: str) -> str:
        self.history.append(("user", text))
        reply = self._handle(text)
        self.history.append(("agent", reply))
        self._save()
        return reply

    def _handle(self, text: str) -> str:
        lowered = text.lower()

        match = re.search(r"my name is (\w+)", text, re.I)
        if match:
            self.facts["name"] = match.group(1).title()
            return f"Nice to meet you, {self.facts['name']}. I'll remember that."

        if re.search(r"what('s| is) my name|who am i", lowered):
            name = self.facts.get("name")
            return f"Your name is {name}." if name else "I don't know your name yet."

        if re.search(r"what do you remember|show (my )?notes", lowered):
            if not self.notes:
                return "I have no notes yet."
            return "I remember:\n" + "\n".join(f"- {note}" for note in self.notes)

        match = re.match(r"\s*remember (?:that )?(.+)", text, re.I)
        if match:
            self.notes.append(match.group(1).strip())
            return f"Noted: {match.group(1).strip()}"

        if len(self.plan(text)) > 1:
            return self.run_plan(text)

        return self.tools.respond(text)
