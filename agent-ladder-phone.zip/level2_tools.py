"""Level 2 - Tool-using agent: chooses the right tool for each request."""

from __future__ import annotations

import re
from dataclasses import dataclass

from tools import calculator, clock, find_expression, format_number, lookup


@dataclass
class ToolResult:
    tool: str
    output: str
    value: float | None = None


class ToolAgent:
    level = 2
    name = "Tool Agent"

    def act(self, text: str) -> ToolResult:
        expression = find_expression(text)
        if expression:
            try:
                value = calculator(expression)
            except ValueError as error:
                return ToolResult("calculator", f"Calculator error: {error}")
            return ToolResult("calculator", f"{expression} = {format_number(value)}", value)

        lowered = text.lower()
        if re.search(r"\b(time|date|day|today)\b", lowered):
            return ToolResult("clock", clock())

        fact = lookup(lowered)
        if fact:
            return ToolResult("lookup", fact)

        return ToolResult("none", "I don't have a tool for that yet.")

    def respond(self, text: str) -> str:
        result = self.act(text)
        return f"[{result.tool}] {result.output}"
