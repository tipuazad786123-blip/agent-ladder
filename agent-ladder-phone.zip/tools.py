"""Shared tools used by the agents. Standard library only, so everything runs offline."""

from __future__ import annotations

import ast
import datetime as _dt
import operator
import re

_BINARY = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos}

KNOWLEDGE = {
    "machine learning": "Machine learning lets software learn patterns from data instead of following hand-written rules.",
    "agent": "An AI agent perceives its environment, decides what to do, and acts to reach a goal.",
    "python": "Python is a high-level programming language known for readable syntax and a huge library ecosystem.",
    "git": "Git is a distributed version control system that tracks changes to source code.",
    "hackathon": "A hackathon is a time-boxed event where teams build working prototypes of new ideas.",
    "api": "An API is a contract that lets one piece of software request services from another.",
    "solar energy": "Solar energy converts sunlight into electricity using photovoltaic panels.",
}


def _eval(node: ast.AST):
    if isinstance(node, ast.Expression):
        return _eval(node.body)
    if (
        isinstance(node, ast.Constant)
        and isinstance(node.value, (int, float))
        and not isinstance(node.value, bool)
    ):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY:
        left, right = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 100:
            raise ValueError("exponent too large")
        return _BINARY[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
        return _UNARY[type(node.op)](_eval(node.operand))
    raise ValueError("unsupported expression")


def calculator(expression: str):
    """Safely evaluate an arithmetic expression. Raises ValueError on anything else."""
    try:
        tree = ast.parse(expression.strip().replace("^", "**"), mode="eval")
        return _eval(tree)
    except ZeroDivisionError:
        raise ValueError("division by zero") from None
    except SyntaxError:
        raise ValueError("invalid expression") from None


def format_number(value) -> str:
    if isinstance(value, int):
        return str(value)
    return str(int(value)) if float(value).is_integer() else f"{value:.6g}"


def clock(now: _dt.datetime | None = None) -> str:
    return (now or _dt.datetime.now()).strftime("%A, %d %B %Y, %H:%M")


def lookup(query: str) -> str | None:
    """Return the best matching fact (longest matching key wins), or None."""
    query = query.lower()
    hits = [key for key in KNOWLEDGE if re.search(rf"\b{re.escape(key)}\b", query)]
    return KNOWLEDGE[max(hits, key=len)] if hits else None


_EXPR_CHARS = re.compile(r"[\d.\s+\-*/%^()]+")


def find_expression(text: str) -> str | None:
    """Find the longest arithmetic-looking fragment in free text, if any."""
    best = None
    for match in _EXPR_CHARS.finditer(text):
        fragment = match.group().strip()
        if re.search(r"\d", fragment) and re.search(r"[+\-*/%^]", fragment):
            if best is None or len(fragment) > len(best):
                best = fragment
    return best
