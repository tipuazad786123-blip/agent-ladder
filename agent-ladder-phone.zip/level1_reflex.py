"""Level 1 - Reflex agent: reacts to keywords. No tools, no memory, no planning."""

from __future__ import annotations

import re


class ReflexAgent:
    level = 1
    name = "Reflex Agent"

    RULES = [
        (r"\bwhat can you do\b", "I match keywords and reply with canned answers. That's all a Level 1 agent does."),
        (r"\b(hello|hi|hey)\b", "Hello! I'm a Level 1 reflex agent. I react to keywords only."),
        (r"\b(thanks|thank you)\b", "You're welcome!"),
        (r"\b(bye|goodbye)\b", "Goodbye!"),
        (r"\bhelp\b", "Try saying hello, thanks, or bye."),
    ]
    DEFAULT = "I don't understand that. I only know a few keywords."

    def respond(self, text: str) -> str:
        lowered = text.lower()
        for pattern, reply in self.RULES:
            if re.search(pattern, lowered):
                return reply
        return self.DEFAULT
