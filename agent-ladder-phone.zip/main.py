"""Command-line runner for AgentLadder.

    python main.py demo            # run all five levels
    python main.py demo --level 3  # run one level
    python main.py chat --level 2  # talk to level 1, 2 or 3
"""

from __future__ import annotations

import argparse

from level1_reflex import ReflexAgent
from level2_tools import ToolAgent
from level3_memory import MemoryAgent
from level4_multi_agent import Orchestrator
from level5_autonomous import AutonomousAgent, Goal


def banner(title: str) -> None:
    print(f"\n=== {title} ===")


def demo_level1() -> None:
    banner("Level 1: Reflex agent")
    agent = ReflexAgent()
    for text in ("hello", "what is 2+2?"):
        print(f"you:   {text}\nagent: {agent.respond(text)}")


def demo_level2() -> None:
    banner("Level 2: Tool-using agent")
    agent = ToolAgent()
    for text in ("what is 12 * (3 + 4)?", "tell me about python", "what is the date today"):
        print(f"you:   {text}\nagent: {agent.respond(text)}")


def demo_level3() -> None:
    banner("Level 3: Memory and planning agent")
    agent = MemoryAgent()
    for text in ("my name is Asha", "remember that the demo is at 10am", "what is my name", "what do you remember",
                 "2+3 then ans*4 then ans-1"):
        print(f"you:   {text}\nagent: {agent.respond(text)}")


def demo_level4() -> None:
    banner("Level 4: Multi-agent team")
    result = Orchestrator().run("Explain machine learning and compute 12*8+4")
    for msg in result.transcript:
        print(f"  {msg.sender:>10} -> {msg.recipient:<10} [{msg.kind}] {msg.content[:60]}")
    print("\n" + result.report)


def demo_level5() -> None:
    banner("Level 5: Autonomous self-improving agent")
    agent = AutonomousAgent()
    for goal in (Goal("Python", 5, 2, 8), Goal("Git", 4, 3, 10)):
        print(f"\nGoal: {goal}")
        result = agent.run(goal)
        for line in result.log:
            print("  " + line)
        print(f"  success={result.success} after {result.iterations} iteration(s)")
        for day in result.plan:
            print(f"    Day {day['day']}: {day['focus']} ({day['hours']}h)")


DEMOS = {1: demo_level1, 2: demo_level2, 3: demo_level3, 4: demo_level4, 5: demo_level5}


def chat(level: int) -> None:
    agent = {1: ReflexAgent, 2: ToolAgent, 3: MemoryAgent}[level]()
    print(f"Chatting with {agent.name}. Type 'quit' to exit.")
    while True:
        try:
            text = input("you: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text.lower() in {"quit", "exit"}:
            break
        print(f"agent: {agent.respond(text)}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    demo_parser = sub.add_parser("demo", help="run scripted demos")
    demo_parser.add_argument("--level", type=int, choices=range(1, 6))
    chat_parser = sub.add_parser("chat", help="chat with level 1, 2 or 3")
    chat_parser.add_argument("--level", type=int, choices=range(1, 4), default=3)
    args = parser.parse_args()

    if args.command == "demo":
        for level in ([args.level] if args.level else DEMOS):
            DEMOS[level]()
    else:
        chat(args.level)


if __name__ == "__main__":
    main()
