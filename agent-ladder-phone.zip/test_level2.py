import unittest

from level2_tools import ToolAgent


class ToolAgentTests(unittest.TestCase):
    def setUp(self):
        self.agent = ToolAgent()

    def test_uses_calculator(self):
        result = self.agent.act("what is 12 * (3 + 4)?")
        self.assertEqual(result.tool, "calculator")
        self.assertEqual(result.value, 84)

    def test_uses_lookup(self):
        self.assertEqual(self.agent.act("tell me about python").tool, "lookup")

    def test_uses_clock(self):
        self.assertEqual(self.agent.act("what is the date today").tool, "clock")

    def test_unknown_request(self):
        self.assertEqual(self.agent.act("sing me a song").tool, "none")

    def test_calculator_error_is_reported(self):
        self.assertIn("division by zero", self.agent.act("10 / 0").output)


if __name__ == "__main__":
    unittest.main()
