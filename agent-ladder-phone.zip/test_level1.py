import unittest

from level1_reflex import ReflexAgent


class ReflexTests(unittest.TestCase):
    def test_greeting(self):
        self.assertIn("Level 1", ReflexAgent().respond("Hello there"))

    def test_unknown_input_uses_default(self):
        self.assertEqual(ReflexAgent().respond("quantum chromodynamics"), ReflexAgent.DEFAULT)

    def test_no_memory(self):
        agent = ReflexAgent()
        self.assertEqual(agent.respond("my name is Asha"), agent.respond("my name is Asha"))
        self.assertEqual(agent.respond("what is my name"), ReflexAgent.DEFAULT)


if __name__ == "__main__":
    unittest.main()
