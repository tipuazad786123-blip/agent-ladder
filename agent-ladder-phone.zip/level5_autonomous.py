"""Level 5 - Autonomous self-improving agent.

Loop: draft -> critique -> reflect -> revise, until the plan meets every constraint.
Lessons learned from one goal are kept and used to start the next goal closer to the answer.
Guardrails: input validation and a hard cap on iterations.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

FOCUS_AREAS = [
    "Fundamentals",
    "Core concepts",
    "Hands-on practice",
    "Mini project",
    "Weak-spot revision",
    "Mock test",
]


@dataclass
class Goal:
    topic: str
    days: int
    hours_per_day: float
    max_total_hours: float


@dataclass
class Strategy:
    days: int = 3
    hours_per_day: float = 4.0
    include_review: bool = False


@dataclass
class Result:
    success: bool
    iterations: int = 0
    plan: list[dict] = field(default_factory=list)
    log: list[str] = field(default_factory=list)
    reason: str = ""


def draft(goal: Goal, strategy: Strategy) -> list[dict]:
    plan = []
    for index in range(strategy.days):
        last_day = index == strategy.days - 1
        focus = "Review & recap" if strategy.include_review and last_day else FOCUS_AREAS[index % len(FOCUS_AREAS)]
        plan.append({"day": index + 1, "focus": f"{goal.topic}: {focus}", "hours": strategy.hours_per_day})
    return plan


def critique(goal: Goal, plan: list[dict]) -> list[str]:
    issues = []
    if len(plan) != goal.days:
        issues.append(f"days: have {len(plan)}, need {goal.days}")
    if any(day["hours"] > goal.hours_per_day for day in plan):
        issues.append("daily hours exceed the limit")
    if sum(day["hours"] for day in plan) > goal.max_total_hours + 1e-9:
        issues.append("total hours exceed the budget")
    if not plan or "Review" not in plan[-1]["focus"]:
        issues.append("final day is not a review day")
    return issues


class AutonomousAgent:
    level = 5
    name = "Autonomous Self-Improving Agent"

    def __init__(self, max_iterations: int = 5, lessons_path: str | Path | None = None):
        self.max_iterations = max_iterations
        self.lessons_path = Path(lessons_path) if lessons_path else None
        self.lessons: dict[str, bool] = {}
        if self.lessons_path and self.lessons_path.exists():
            self.lessons = json.loads(self.lessons_path.read_text())

    def _remember(self, key: str) -> None:
        self.lessons[key] = True
        if self.lessons_path:
            self.lessons_path.write_text(json.dumps(self.lessons, indent=2))

    def _validate(self, goal: Goal) -> str:
        if not goal.topic.strip():
            return "Refused: the goal has no topic."
        if not 1 <= goal.days <= 60:
            return "Refused: days must be between 1 and 60."
        if goal.hours_per_day <= 0 or goal.max_total_hours <= 0:
            return "Refused: hours must be positive."
        return ""

    def _initial_strategy(self, goal: Goal) -> Strategy:
        strategy = Strategy(include_review=self.lessons.get("include_review", False))
        if self.lessons.get("use_goal_constraints"):
            strategy.days = goal.days
            strategy.hours_per_day = min(goal.hours_per_day, goal.max_total_hours / goal.days)
        return strategy

    def _reflect(self, goal: Goal, strategy: Strategy, issues: list[str]) -> None:
        for issue in issues:
            if issue.startswith("days"):
                strategy.days = goal.days
                self._remember("use_goal_constraints")
            elif issue.startswith("daily"):
                strategy.hours_per_day = goal.hours_per_day
                self._remember("use_goal_constraints")
            elif issue.startswith("total"):
                strategy.hours_per_day = min(strategy.hours_per_day, round(goal.max_total_hours / goal.days, 2))
                self._remember("use_goal_constraints")
            elif issue.startswith("final"):
                strategy.include_review = True
                self._remember("include_review")

    def run(self, goal: Goal) -> Result:
        problem = self._validate(goal)
        if problem:
            return Result(False, reason=problem, log=[problem])

        strategy = self._initial_strategy(goal)
        result = Result(False)
        for iteration in range(1, self.max_iterations + 1):
            plan = draft(goal, strategy)
            issues = critique(goal, plan)
            result.iterations = iteration
            result.plan = plan
            if not issues:
                result.success = True
                result.log.append(f"Iteration {iteration}: plan passed every check.")
                return result
            result.log.append(f"Iteration {iteration}: problems found -> {'; '.join(issues)}")
            self._reflect(goal, strategy, issues)
            result.log.append(f"Iteration {iteration}: revised strategy -> {strategy}")

        result.reason = "Stopped: max iterations reached without a valid plan."
        result.log.append(result.reason)
        return result
