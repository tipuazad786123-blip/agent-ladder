import unittest

from tools import calculator, find_expression, format_number, lookup


class ToolTests(unittest.TestCase):
    def test_calculator(self):
        self.assertEqual(calculator("12 * (3 + 4)"), 84)
        self.assertEqual(calculator("2^3"), 8)

    def test_calculator_rejects_code(self):
        with self.assertRaises(ValueError):
            calculator("__import__('os').system('echo hi')")

    def test_division_by_zero(self):
        with self.assertRaises(ValueError):
            calculator("1/0")

    def test_lookup_prefers_longest_key(self):
        self.assertIn("learn patterns", lookup("tell me about machine learning"))
        self.assertIsNone(lookup("something unknown"))

    def test_find_expression(self):
        self.assertEqual(find_expression("what is 12 * (3 + 4)?"), "12 * (3 + 4)")
        self.assertIsNone(find_expression("I have 2 apples"))

    def test_format_number(self):
        self.assertEqual(format_number(5.0), "5")
        self.assertEqual(format_number(2.5), "2.5")


if __name__ == "__main__":
    unittest.main()
