# AgentLadder

> Five levels of AI agents in one small Python project, from a keyword bot to an agent that critiques and improves its own work.

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![Tests](https://img.shields.io/badge/tests-passing-brightgreen)
![License](https://img.shields.io/badge/license-MIT-blue)

## Table of Contents

- [About](#about)
- [The Five Levels](#the-five-levels)
- [Skills](#skills)
- [Getting Started](#getting-started)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Guardrails](#guardrails)
- [Contributing](#contributing)
- [License](#license)

## About

Most people say "AI agent" and mean very different things. AgentLadder makes the differences concrete: each level adds exactly one capability on top of the last, so you can read, run and test the progression in minutes. Everything uses only the Python standard library and runs offline with no API key.

## The Five Levels

| Level | Agent | New capability | File |
| ----- | ----- | -------------- | ---- |
| 1 | Reflex agent | Reacts to keywords with canned replies | `level1_reflex.py` |
| 2 | Tool agent | Picks the right tool: calculator, clock, knowledge lookup | `level2_tools.py` |
| 3 | Memory and planning agent | Remembers facts and notes, runs multi-step plans | `level3_memory.py` |
| 4 | Multi-agent team | Planner, researcher, analyst and writer cooperate through a message bus | `level4_multi_agent.py` |
| 5 | Autonomous self-improving agent | Drafts, critiques, reflects and revises; learns lessons for the next goal | `level5_autonomous.py` |

Level 5 example: asked for a 5-day study plan with 2 hours per day and an 8-hour budget, the agent's first draft breaks four constraints. It finds each problem, fixes its strategy, and succeeds on the second iteration. On the next goal it starts from what it learned and succeeds on the first try.

## Skills

- **AI agent design**: reflex, tool-use, memory, multi-agent and self-improving architectures
- **Python**: dataclasses, type hints, safe expression parsing with `ast`
- **Multi-agent orchestration**: message passing between specialist agents
- **Testing**: unit tests for every level, including guardrail behaviour
- **Git & GitHub**: one focused commit per level

## Getting Started

### Prerequisites

- Python 3.10 or newer
- Git

### Installation

```bash
git clone https://github.com/tipuazad786123-blip/agent-ladder.git
cd agent-ladder
```

There are no dependencies to install.

## Usage

```bash
python main.py demo             # run all five levels
python main.py demo --level 5   # run a single level
python main.py chat --level 3   # chat with level 1, 2 or 3
python -m unittest discover   # run the tests
```

Example, Level 3 plan (`ans` means the previous result):

```text
you:   2+3 then ans*4 then ans-1
agent: Step 1: 2+3 -> 2+3 = 5
       Step 2: 5*4 -> 5*4 = 20
       Step 3: 20-1 -> 20-1 = 19
```

## Project Structure

```
.
├── tools.py                   # calculator, clock, lookup
├── level1_reflex.py
├── level2_tools.py
├── level3_memory.py
├── level4_multi_agent.py
├── level5_autonomous.py
├── test_*.py                  # one test file per level
├── main.py                    # demo and chat runner
├── AgentLadder.pptx           # pitch deck
└── README.md
```

## Guardrails

- The calculator parses expressions with `ast`, so it never runs arbitrary code, and it caps exponents.
- The Level 4 orchestrator stops after a maximum number of messages.
- The Level 5 agent validates goals, refuses invalid ones, and stops after a maximum number of iterations.

## Contributing

1. Fork the repository
2. Create a branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m "Add my feature"`
4. Push the branch: `git push origin feature/my-feature`
5. Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for details.
