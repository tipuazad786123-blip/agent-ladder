import unittest

from level5_autonomous import AutonomousAgent, Goal


class AutonomousAgentTests(unittest.TestCase):
    def test_agent_fixes_its_own_plan(self):
        result = AutonomousAgent().run(Goal("Python", days=5, hours_per_day=2, max_total_hours=8))
        self.assertTrue(result.success)
        self.assertGreater(result.iterations, 1)
        self.assertEqual(len(result.plan), 5)
        self.assertIn("Review", result.plan[-1]["focus"])
        self.assertLessEqual(sum(d["hours"] for d in result.plan), 8 + 1e-9)

    def test_learns_from_previous_goal(self):
        agent = AutonomousAgent()
        first = agent.run(Goal("Python", 5, 2, 8))
        second = agent.run(Goal("Git", 4, 3, 10))
        self.assertTrue(second.success)
        self.assertLess(second.iterations, first.iterations)
        self.assertEqual(second.iterations, 1)

    def test_refuses_invalid_goal(self):
        result = AutonomousAgent().run(Goal("", 5, 2, 8))
        self.assertFalse(result.success)
        self.assertTrue(result.reason.startswith("Refused"))

    def test_iteration_guardrail(self):
        result = AutonomousAgent(max_iterations=1).run(Goal("Python", 5, 2, 8))
        self.assertFalse(result.success)
        self.assertIn("max iterations", result.reason)


if __name__ == "__main__":
    unittest.main()
