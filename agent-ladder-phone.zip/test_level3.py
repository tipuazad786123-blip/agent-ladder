import tempfile
import unittest
from pathlib import Path

from level3_memory import MemoryAgent


class MemoryAgentTests(unittest.TestCase):
    def test_remembers_name(self):
        agent = MemoryAgent()
        self.assertIn("don't know", agent.respond("what is my name"))
        agent.respond("my name is asha")
        self.assertEqual(agent.respond("what is my name"), "Your name is Asha.")

    def test_notes(self):
        agent = MemoryAgent()
        agent.respond("remember that the demo is at 10am")
        self.assertIn("demo is at 10am", agent.respond("what do you remember"))

    def test_plan_splitting(self):
        self.assertEqual(MemoryAgent.plan("2+3 then ans*4; ans-1"), ["2+3", "ans*4", "ans-1"])

    def test_multi_step_plan_uses_previous_result(self):
        reply = MemoryAgent().respond("2+3 then ans*4 then ans-1")
        self.assertTrue(reply.rstrip().endswith("19"))

    def test_memory_persists_to_disk(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "memory.json"
            MemoryAgent(path).respond("my name is Ravi")
            self.assertEqual(MemoryAgent(path).respond("who am i"), "Your name is Ravi.")


if __name__ == "__main__":
    unittest.main()
